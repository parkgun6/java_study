package d1;

public class Study2 {

	public static void main(String[] args) {
		
		int x = 5^9;
		System.out.println(x);
	}
}
