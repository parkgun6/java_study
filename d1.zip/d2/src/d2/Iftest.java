package d2;

import java.util.Scanner;

public class Iftest {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("잔돈을 입력하세요.");
		int coin = scanner.nextInt();
		
	
			
		}
	}

