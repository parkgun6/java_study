package d2;

public class ForEx {
	
	public static void main(String[] args) {
		int i = 0;
		for (System.out.println("a");true;System.out.println("b")) {
			System.out.println(i);
			i++;
			break;
		}
	}
}
